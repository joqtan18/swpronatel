<?php $__env->startSection('contenido'); ?>
    <div class="row mt-0">
        <div class="col-md-6">
            <a href="<?php echo e(url('revision/create')); ?>" class="btn btn-primary">Registrar Tableta</a>
            <a href="<?php echo e(url('reporterevisionexcel/')); ?>" class="btn btn-success"><i class="fa fa-file-excel"></i></a>
        </div>
        <div class="col-md-6">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row mt-1">
        <dir class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>Registro de Revisiones de Tablets</strong>
                </div>
                <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>DNI</th>
                                <th>N° Serie</th>
                                <th>Marca</th>
                                <th>Propietario</th>
                                <th>Palet</th>
                                <th>Hora</th>
                                <th>Estado Tableta</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($rev->usuario); ?></td>
                                <td><?php echo e($rev->n_serie); ?></td>
                                <td><?php echo e($rev->marca); ?></td>
                                <td><?php echo e($rev->trab_nom.', '.$rev->trab_ape); ?></td>
                                <td><?php echo e($rev->n_palet); ?></td>
                                <td><?php echo e($rev->hora); ?></td>
                                <td>
                                    <?php if($rev->estado == 0): ?>
                                        <span class="badge badge-success">Operativa</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Observada</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a data-toggle="modal" class="btn btn-sm btn-info" title="Info de tableta"><i class="fa fa-search"></i></a>
                                    <a data-toggle="modal" class="btn btn-sm btn-warning" title="editar tableta"><i class="fa fa-edit"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </dir>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\SISTEMASWEB\swpronatel\resources\views/revision/index.blade.php ENDPATH**/ ?>