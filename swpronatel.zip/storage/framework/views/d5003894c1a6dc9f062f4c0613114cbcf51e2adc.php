<?php $__env->startSection('contenido'); ?>
    <div class="col-md-12">
        <div class="card card-blue">
            <div class="card-header">
                <h3 class="card-title">Revision de la Tableta</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <form role="form" action="<?php echo e(url('revision')); ?>" method="POST" class="form-horizontal">
                    <?php echo method_field('POST'); ?>
                    <?php echo e(csrf_field()); ?>

                    <?php if(count($errors)>0): ?>
                        <div class="alert alert-danger">
                            <p>Corregir los siguientes campos:</p>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-sm-6">
                            <!-- radio -->
                            <div class="form-group">
                                <label for="">Estado de la Tablet</label><code> *</code>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="estadotablet" value="0" required>
                                    <label class="form-check-label">Operativa</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="estadotablet" value="1" required>
                                    <label class="form-check-label">Observada</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-actions">
                        <input type="submit" value="Siguiente" class="btn btn-primary">

                        <a href="<?php echo e(url('revision')); ?>" class="btn btn-danger">Cancelar</a>
                    </div>
                </form>
            </div>
            <!-- /.card-body -->
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\SISTEMASWEB\swpronatel\resources\views/revision/create.blade.php ENDPATH**/ ?>