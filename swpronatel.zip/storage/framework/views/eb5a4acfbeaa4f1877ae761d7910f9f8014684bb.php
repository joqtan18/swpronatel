<?php $__env->startSection('contenido'); ?>
    <div class="row mt-0">
        <div class="col-md-6">
            <a href="<?php echo e(url('ingeniero/create')); ?>" class="btn btn-primary">Registrar Ingeniero</a>
        </div>
        <div class="col-md-6">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row mt-1">
        <dir class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>Ingenieros</strong>
                </div>
                <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>DNI</th>
                            <th>Apellidos</th>
                            <th>Nombres</th>
                            <th>Sexo</th>
                            <th>Estado</th>
                            <th>Opciones</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($trab->trab_dni); ?></td>
                                <td><?php echo e($trab->trab_ape); ?></td>
                                <td><?php echo e($trab->trab_nom); ?></td>
                                <td>
                                    <?php if($trab->trab_sexo == 1): ?>
                                        Masculino
                                    <?php else: ?>
                                        Femenino
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($trab->trab_est == 1): ?>
                                        <span class="badge badge-success">Activo</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Inactivo</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a data-toggle="modal" class="btn btn-sm btn-info" title="Info de tableta"><i class="fa fa-search"></i></a>
                                    <?php if($trab->trab_est == 1): ?>
                                        <a data-toggle="modal" data-target="#modal-est-<?php echo e($trab->trab_id); ?>" title="Inactivar usuario" class="btn btn-sm btn-success"><i class="fa fa-toggle-on"></i></a>
                                    <?php else: ?>
                                        <a data-toggle="modal" data-target="#modal-est-<?php echo e($trab->trab_id); ?>" title="Activar usuario" class="btn btn-sm btn-danger"><i class="fa fa-toggle-off"></i></a>
                                    <?php endif; ?>
                                    <?php echo $__env->make('ingeniero.estado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <a data-toggle="modal" class="btn btn-sm btn-warning" title="editar tableta"><i class="fa fa-edit"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </dir>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\SISTEMASWEB\swpronatel\resources\views/ingeniero/index.blade.php ENDPATH**/ ?>