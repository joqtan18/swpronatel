<div class="modal fade" id="modal-est-<?php echo e($trab->trab_id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(url('ingeniero/'.$trab->trab_id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="modal-body">
                    <?php if($trab->trab_est == 1): ?>
                        <h5>¿Deseas inactivar al usuario?</h5>
                        <b><?php echo e($trab->trab_nom.','.$trab->trab_ape); ?></b>
                    <?php elseif($trab->trab_est == 0): ?>
                        <h5>¿Deseas activar al usuario?</h5>
                        <b><?php echo e($trab->trab_nom.','.$trab->trab_ape); ?></b>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <input type="submit" value="SI" class="btn btn-primary">
                    <a href="<?php echo e(url('ingeniero')); ?>" class="btn btn-danger">NO</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\SISTEMASWEB\swpronatel\resources\views/ingeniero/estado.blade.php ENDPATH**/ ?>