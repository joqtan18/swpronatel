@extends('plantilla.plantilla')
@section('contenido')
    prueba de reporte mensual de grafico
@endsection
@section('scripts')
@endsection
