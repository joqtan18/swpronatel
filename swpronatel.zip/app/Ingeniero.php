<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ingeniero extends Model
{
    //
}
